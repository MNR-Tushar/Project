package com.diuhealthsheba.diuhealthsheba.service;

import com.diuhealthsheba.diuhealthsheba.dto.UserDto;
import com.diuhealthsheba.diuhealthsheba.model.User;

public interface UserService {
	
	User save (UserDto userDto);
	

}
