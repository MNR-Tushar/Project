package com.diuhealthsheba.diuhealthsheba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiuhealthshebaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiuhealthshebaApplication.class, args);
	}

}
