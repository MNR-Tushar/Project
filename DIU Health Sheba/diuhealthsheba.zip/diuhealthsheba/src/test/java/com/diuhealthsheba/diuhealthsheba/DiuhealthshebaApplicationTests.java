package com.diuhealthsheba.diuhealthsheba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiuhealthshebaApplicationTests {

	@Test
	void contextLoads() {
	}

}
